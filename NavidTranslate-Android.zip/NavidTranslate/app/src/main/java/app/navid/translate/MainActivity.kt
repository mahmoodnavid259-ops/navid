package app.navid.translate

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import java.util.Locale

private val Blue1 = Color(0xFF1F5FF0)
private val Blue2 = Color(0xFF0B2A9E)
private val Gold = Color(0xFFF5B82E)
private val Bg = Color(0xFFF3F6FD)
private val Muted = Color(0xFF6B7385)
private enum class Screen { Home, History, Favs, Offline }

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme { NavidApp() }
            }
        }
    }
}

@Composable
private fun NavidApp() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val scope = rememberCoroutineScope()
    var token by remember { mutableStateOf(store.token) }
    var allowed by remember { mutableStateOf(store.allowed) }
    LaunchedEffect(Unit) { if (Api.enabled) Api.config()?.let { allowed = it; store.allowed = it } }
    if (Api.enabled && token.isEmpty()) { Login { token = it; store.token = it }; return }

    val langs = remember(allowed) { Engine.langs(allowed) }
    var src by remember { mutableStateOf("auto") }
    var dst by remember { mutableStateOf(if (langs.any { it.id == "en" }) "en" else langs.first().id) }
    var input by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var screen by remember { mutableStateOf(Screen.Home) }
    var tab by remember { mutableStateOf("t") }
    var dialog by remember { mutableStateOf<Pair<String, String>?>(null) }
    val history = remember { mutableStateListOf<Item>().apply { addAll(store.list("hist")) } }
    val favs = remember { mutableStateListOf<Item>().apply { addAll(store.list("fav")) } }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val tts = remember { TextToSpeech(ctx) {} }
    DisposableEffect(Unit) { onDispose { tts.shutdown() } }

    fun code(id: String) = if (id == "auto") "auto" else langs.firstOrNull { it.id == id }?.code ?: id
    fun name(id: String) = if (id == "auto") "تشخیص خودکار" else langs.firstOrNull { it.id == id }?.name ?: id
    val cur = Item(src, dst, input, output)
    val isFav = output.isNotEmpty() && favs.any { it.i == input && it.t == dst }

    fun speak(text: String, c: String) {
        if (text.isBlank()) return
        if (tts.setLanguage(Locale.forLanguageTag(c)) < 0) { msg = "صدای این زبان روی دستگاه نصب نیست"; return }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    fun go(kind: String = "text") {
        if (input.isBlank()) { msg = "متنی وارد نشده است"; return }
        scope.launch {
            busy = true; msg = ""
            try {
                var sc = code(src)
                if (sc == "auto") sc = Engine.detect(input) ?: throw Exception("زبان تشخیص داده نشد")
                val tc = code(dst)
                output = Engine.translate(input, sc, tc)
                history.add(0, Item(src, dst, input, output)); store.save("hist", history)
                if (Api.enabled) { val c = Api.event(token, sc, tc, kind); if (c == 401 || c == 403) { store.token = ""; token = "" } }
            } catch (e: Exception) {
                msg = "ترجمه ناموفق بود. اگر بسته‌ی این زبان دانلود نشده، یک‌بار با اینترنت دانلودش کنید."
            } finally { busy = false }
        }
    }

    fun startMic() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { msg = "تشخیص گفتار روی این دستگاه نیست"; return }
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(b: Bundle) {
                input = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                msg = ""; r.destroy(); if (input.isNotBlank()) go("voice")
            }
            override fun onError(e: Int) { msg = "خطای تشخیص گفتار ($e)"; r.destroy() }
            override fun onReadyForSpeech(p: Bundle?) { msg = "در حال گوش دادن…" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        val lang = if (src == "auto") "fa" else code(src)
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true))
    }

    suspend fun ocrAndGo(b: android.graphics.Bitmap) {
        msg = "در حال خواندن متن تصویر…"
        val t = try { Engine.ocr(ctx, b, if (src == "auto") "fa" else code(src)).trim() } catch (e: Exception) { "" }
        if (t.isBlank()) { msg = "متنی پیدا نشد. برای فارسی و عربی، فایل‌های tessdata باید در برنامه باشند (README)"; return }
        input = t; go("image")
    }

    val camL = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { b -> b?.let { scope.launch { ocrAndGo(it) } } }
    val galL = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        u?.let { ctx.contentResolver.openInputStream(it)?.use { s -> BitmapFactory.decodeStream(s) }?.let { b -> scope.launch { ocrAndGo(b) } } }
    }
    val micL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) startMic() else msg = "دسترسی میکروفون داده نشد" }

    fun onTab(k: String) {
        tab = k
        when (k) {
            "v" -> if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startMic() else micL.launch(Manifest.permission.RECORD_AUDIO)
            "c" -> camL.launch(null)
            "i" -> galL.launch("image/*")
        }
    }
    fun openAdmin() { if (Api.enabled) ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Api.adminUrl))) else dialog = "پنل مدیریت" to "ابتدا آدرس سرور (BASE_URL) را در app/build.gradle.kts تنظیم کنید." }

    val menu = listOf(
        "🌐" to "مدیریت زبان‌ها" to { screen = Screen.Offline },
        "⬇️" to "دانلود بسته‌های زبان" to { screen = Screen.Offline },
        "⚙️" to "تنظیمات برنامه" to { dialog = "تنظیمات برنامه" to "پاک کردن تاریخچه و علاقه‌مندی‌ها از همین دستگاه." },
        "👥" to "مدیریت کاربران" to { openAdmin() },
        "🛡️" to "پنل مدیریت (ادمین)" to { openAdmin() },
        "📊" to "آمار و گزارش‌ها" to { openAdmin() },
        "❓" to "راهنما و پشتیبانی" to { dialog = "راهنما" to "زبان‌ها را انتخاب کنید و «ترجمه کن» را بزنید. برای کار بدون اینترنت، از تب «آفلاین» بسته‌ی زبان را یک‌بار دانلود کنید." },
        "ℹ️" to "درباره ما" to { dialog = "درباره ما" to "Navid Translate نسخه‌ی ۱٫۰" })

    ModalNavigationDrawer(drawerState = drawer, drawerContent = {
        ModalDrawerSheet {
            Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Blue1, Blue2))).statusBarsPadding().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("🌐", fontSize = 44.sp)
                Row { Text("Navid ", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("Translate", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold) }
                Text("ترجمه به تمام زبان‌های جهان", color = Color.White, fontSize = 13.sp)
            }
            menu.forEach { (ie, action) ->
                val (icon, label) = ie
                NavigationDrawerItem(icon = { Text(icon, fontSize = 20.sp) }, label = { Text(label, fontSize = 16.sp) }, selected = false,
                    onClick = { scope.launch { drawer.close() }; action() })
            }
            Spacer(Modifier.weight(1f))
            Button(onClick = { scope.launch { drawer.close() }; if (Api.enabled) { store.token = ""; token = "" } }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                modifier = Modifier.fillMaxWidth().padding(16.dp)) { Text("خروج", fontWeight = FontWeight.Bold) }
        }
    }) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Box(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Blue1, Blue2))).statusBarsPadding()) {
                Text("PRO", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.TopStart).padding(14.dp).background(Color(0xFF8A5A00), RoundedCornerShape(4.dp)).padding(horizontal = 5.dp))
                Text("⚙", color = Color.White, fontSize = 28.sp, modifier = Modifier.align(Alignment.TopEnd).padding(12.dp).clickable { scope.launch { drawer.open() } })
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🌐", fontSize = 52.sp)
                    Row { Text("Navid ", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold); Text("Translate", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Bold) }
                    Text("ترجمه هوشمند، بدون اینترنت ✅", color = Color.White, fontSize = 14.sp)
                    if (screen == Screen.Home) CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Row(Modifier.fillMaxWidth().padding(top = 12.dp, start = 8.dp, end = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("t" to "⌨️ متن", "v" to "🎙️ صدا", "c" to "📷 دوربین", "i" to "🖼️ تصویر").forEach { (k, l) ->
                                Box(Modifier.weight(1f).clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp)).background(if (tab == k) Bg else Color.White.copy(alpha = .88f)).clickable { onTab(k) }.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                                    Text(l, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF14213D))
                                }
                            }
                        }
                    } else Spacer(Modifier.height(14.dp))
                }
            }
            Box(Modifier.weight(1f)) {
                when (screen) {
                    Screen.Home -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
                        LangPick("زبان مبدأ:", name(src), listOf(Lang("auto", "auto", "تشخیص خودکار")) + langs) { src = it }
                        Spacer(Modifier.height(6.dp))
                        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.padding(12.dp)) {
                                Text("✕", fontSize = 20.sp, modifier = Modifier.clickable { input = ""; output = ""; msg = "" })
                                TextField(value = input, onValueChange = { input = it }, placeholder = { Text("متن را بنویسید…") }, modifier = Modifier.fillMaxWidth(), textStyle = androidx.compose.ui.text.TextStyle(fontSize = 19.sp),
                                    colors = TextFieldDefaults.colors(focusedContainerColor = Color.White, unfocusedContainerColor = Color.White, focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent))
                                Text("🔊", fontSize = 22.sp, modifier = Modifier.clickable { speak(input, if (src == "auto") "fa" else code(src)) })
                            }
                        }
                        Box(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                            Box(Modifier.size(52.dp).clip(CircleShape).background(Blue1).clickable {
                                val s = if (src == "auto") "dr" else src; src = dst; dst = s
                                if (output.isNotEmpty()) { input = output; go() }
                            }, contentAlignment = Alignment.Center) { Text("⇄", color = Color.White, fontSize = 24.sp) }
                        }
                        LangPick("زبان مقصد:", name(dst), langs) { dst = it }
                        Spacer(Modifier.height(6.dp))
                        Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                                Text(output, fontSize = 21.sp, modifier = Modifier.heightIn(min = 70.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                                    Text("🔊", fontSize = 22.sp, modifier = Modifier.clickable { speak(output, code(dst)) })
                                    Text("📋", fontSize = 22.sp, modifier = Modifier.clickable { if (output.isNotEmpty()) { (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("t", output)); msg = "کپی شد" } })
                                    Text(if (isFav) "★" else "☆", fontSize = 22.sp, modifier = Modifier.clickable {
                                        if (output.isNotEmpty()) { if (isFav) favs.removeAll { it.i == input && it.t == dst } else favs.add(0, cur); store.save("fav", favs) }
                                    })
                                    Text("🔗", fontSize = 22.sp, modifier = Modifier.clickable { if (output.isNotEmpty()) ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, output), null)) })
                                }
                            }
                        }
                        Button(onClick = { go() }, enabled = !busy, shape = RoundedCornerShape(28.dp), colors = ButtonDefaults.buttonColors(containerColor = Blue1), modifier = Modifier.fillMaxWidth().padding(top = 14.dp).height(52.dp)) {
                            if (busy) CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp) else Text("ترجمه کن", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                        if (msg.isNotEmpty()) Text(msg, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                    }
                    Screen.History -> ItemList("هنوز ترجمه‌ای انجام نشده است.", history, ::name) { src = it.s; dst = it.t; input = it.i; output = it.o; screen = Screen.Home }
                    Screen.Favs -> ItemList("با ستاره، ترجمه‌ها را اینجا ذخیره کنید.", favs, ::name) { src = it.s; dst = it.t; input = it.i; output = it.o; screen = Screen.Home }
                    Screen.Offline -> OfflineScreen(langs.filter { it.id != "dr" })
                }
            }
            NavigationBar(containerColor = Color.White, modifier = Modifier.navigationBarsPadding()) {
                listOf(Screen.Home to "🏠 خانه", Screen.History to "🕘 تاریخچه", Screen.Favs to "⭐ علاقه‌مندی‌ها", Screen.Offline to "⬇️ آفلاین").forEach { (s, l) ->
                    NavigationBarItem(selected = screen == s, onClick = { screen = s }, icon = { Text(l.substringBefore(' '), fontSize = 20.sp) }, label = { Text(l.substringAfter(' '), fontSize = 11.sp) })
                }
            }
        }
    }

    dialog?.let { (t, m) ->
        AlertDialog(onDismissRequest = { dialog = null }, title = { Text(t) }, text = { Text(m) },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("باشه") } },
            dismissButton = if (t == "تنظیمات برنامه") ({ TextButton(onClick = { history.clear(); favs.clear(); store.save("hist", history); store.save("fav", favs); dialog = null }) { Text("پاک کردن", color = Color.Red) } }) else null)
    }
}

@Composable
private fun LangPick(label: String, current: String, options: List<Lang>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 14.sp)
        Box {
            Text("$current ▾", modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(Color(0xFFE6ECFB)).clickable { open = true }.padding(horizontal = 16.dp, vertical = 8.dp), fontWeight = FontWeight.Medium)
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                options.forEach { l -> DropdownMenuItem(text = { Text(l.name) }, onClick = { open = false; onPick(l.id) }) }
            }
        }
    }
}

@Composable
private fun ItemList(empty: String, list: List<Item>, name: (String) -> String, onPick: (Item) -> Unit) {
    if (list.isEmpty()) { Text(empty, color = Muted, modifier = Modifier.padding(20.dp)); return }
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(list) { it ->
            Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth().clickable { onPick(it) }) {
                Column(Modifier.padding(12.dp)) {
                    Text("${name(it.s)} ⇢ ${name(it.t)}", color = Muted, fontSize = 12.sp)
                    Text(it.i, maxLines = 2); Text(it.o, maxLines = 2, color = Blue1)
                }
            }
        }
    }
}

@Composable
private fun OfflineScreen(langs: List<Lang>) {
    val scope = rememberCoroutineScope()
    var have by remember { mutableStateOf(setOf<String>()) }
    var working by remember { mutableStateOf(setOf<String>()) }
    LaunchedEffect(Unit) { have = try { Engine.downloaded() } catch (e: Exception) { emptySet() } }
    LazyColumn(Modifier.fillMaxSize().padding(14.dp)) {
        items(langs) { l ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(l.name, fontSize = 16.sp)
                if (l.code in working) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                else if (l.code in have) TextButton(onClick = { scope.launch { working = working + l.code; try { Engine.delete(l.code); have = have - l.code } catch (e: Exception) {}; working = working - l.code } }) { Text("✓ حذف") }
                else OutlinedButton(onClick = { scope.launch { working = working + l.code; try { Engine.download(l.code); have = have + l.code } catch (e: Exception) {}; working = working - l.code } }) { Text("دانلود") }
            }
        }
    }
}

@Composable
private fun Login(onToken: (String) -> Unit) {
    var e by remember { mutableStateOf("") }
    var p by remember { mutableStateOf("") }
    var m by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    fun send(path: String) = scope.launch {
        busy = true; m = ""
        val (t, c) = Api.auth(path, e.trim(), p)
        if (t != null) onToken(t) else m = when (c) { 0 -> "اتصال به سرور برقرار نشد"; 409 -> "این ایمیل قبلاً ثبت شده"; 403 -> "ثبت‌نام بسته است یا حساب مسدود است"; 400 -> "ایمیل یا رمز نامعتبر (رمز حداقل ۱۰ نویسه)"; else -> "ایمیل یا رمز اشتباه است" }
        busy = false
    }
    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("🌐", fontSize = 56.sp)
        Row { Text("Navid ", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Blue2); Text("Translate", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Gold) }
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(e, { e = it }, label = { Text("ایمیل") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(p, { p = it }, label = { Text("رمز عبور") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
        Row(Modifier.fillMaxWidth().padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { send("/api/login") }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("ورود") }
            OutlinedButton(onClick = { send("/api/register") }, enabled = !busy, modifier = Modifier.weight(1f)) { Text("ثبت‌نام") }
        }
        if (m.isNotEmpty()) Text(m, color = Color(0xFFDC2626), textAlign = TextAlign.Center, modifier = Modifier.padding(top = 10.dp))
    }
}
