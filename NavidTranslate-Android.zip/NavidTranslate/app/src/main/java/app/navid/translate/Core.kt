package app.navid.translate

import android.content.Context
import android.graphics.Bitmap
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

data class Lang(val id: String, val code: String, val name: String)
data class Item(val s: String, val t: String, val i: String, val o: String)

/** On-device translation, language detection and OCR (ML Kit). */
object Engine {
    private val translators = HashMap<String, Translator>()

    fun langs(allowed: Set<String>): List<Lang> {
        val base = TranslateLanguage.getAllLanguages().map {
            Lang(it, it, if (it == "fa") "فارسی" else Locale(it).getDisplayName(Locale(it)).replaceFirstChar { c -> c.uppercase() })
        }
        val all = listOf(Lang("dr", "fa", "دری")) + base
        return if (allowed.isEmpty()) all else all.filter { it.code in allowed }
    }

    suspend fun detect(text: String): String? {
        val c = LanguageIdentification.getClient().identifyLanguage(text).await()
        return if (c == "und") null else c
    }

    suspend fun translate(text: String, s: String, t: String): String {
        if (s == t) return text
        val tr = translators.getOrPut("$s>$t") {
            Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(s).setTargetLanguage(t).build())
        }
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build()).await() // instant when already on device
        return tr.translate(text).await()
    }

    suspend fun downloaded(): Set<String> =
        RemoteModelManager.getInstance().getDownloadedModels(TranslateRemoteModel::class.java).await().map { it.language }.toSet()

    suspend fun download(code: String) {
        RemoteModelManager.getInstance().download(TranslateRemoteModel.Builder(code).build(), DownloadConditions.Builder().build()).await()
    }

    suspend fun delete(code: String) {
        RemoteModelManager.getInstance().deleteDownloadedModel(TranslateRemoteModel.Builder(code).build()).await()
    }

    private val TESS = mapOf("fa" to "fas", "ar" to "ara", "ur" to "urd", "ps" to "pus")

    /** Persian/Arabic/Urdu/Pashto use Tesseract (needs .traineddata in assets/tessdata); other languages use ML Kit. */
    suspend fun ocr(ctx: Context, bmp: Bitmap, lang: String): String {
        val tl = TESS[lang] ?: return TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .process(InputImage.fromBitmap(bmp, 0)).await().text
        return withContext(Dispatchers.Default) {
            val langs = "$tl+eng"
            val dir = File(ctx.filesDir, "tessdata").apply { mkdirs() }
            langs.split("+").forEach { l ->
                val f = File(dir, "$l.traineddata")
                if (!f.exists()) ctx.assets.open("tessdata/$l.traineddata").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            }
            val api = TessBaseAPI()
            try {
                if (!api.init(ctx.filesDir.absolutePath, langs)) throw IllegalStateException("tess init")
                api.setImage(bmp)
                api.utf8Text ?: ""
            } finally { api.recycle() }
        }
    }
}

/** Talks to navid-backend. Disabled until BASE_URL is set. */
object Api {
    val enabled get() = !BuildConfig.BASE_URL.contains("YOUR-SERVER")
    val adminUrl get() = BuildConfig.BASE_URL + "/admin/"

    private suspend fun call(method: String, path: String, body: JSONObject? = null, token: String? = null): Pair<Int, String> =
        withContext(Dispatchers.IO) {
            try {
                val c = URL(BuildConfig.BASE_URL + path).openConnection() as HttpURLConnection
                c.requestMethod = method; c.connectTimeout = 8000; c.readTimeout = 8000
                c.setRequestProperty("Content-Type", "application/json")
                token?.let { c.setRequestProperty("Authorization", "Bearer $it") }
                if (body != null) { c.doOutput = true; c.outputStream.use { it.write(body.toString().toByteArray()) } }
                val code = c.responseCode
                val txt = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
                code to txt
            } catch (e: Exception) { 0 to "" }
        }

    suspend fun auth(path: String, email: String, pw: String): Pair<String?, Int> {
        val (c, t) = call("POST", path, JSONObject().put("email", email).put("password", pw))
        return (if (c == 200) JSONObject(t).optString("token") else null) to c
    }

    suspend fun config(): Set<String>? {
        val (c, t) = call("GET", "/api/config")
        if (c != 200) return null
        val a = JSONObject(t).getJSONArray("languages")
        return (0 until a.length()).map { a.getJSONObject(it).getString("code") }.toSet()
    }

    suspend fun event(tok: String, s: String, d: String, kind: String): Int =
        call("POST", "/api/event", JSONObject().put("src", s.take(12)).put("dst", d.take(12)).put("kind", kind), tok).first
}

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("navid", 0)
    var token: String
        get() = p.getString("token", "") ?: ""
        set(v) { p.edit().putString("token", v).apply() }
    var allowed: Set<String>
        get() = p.getStringSet("allowed", emptySet()) ?: emptySet()
        set(v) { p.edit().putStringSet("allowed", v).apply() }

    fun list(k: String): List<Item> {
        val a = JSONArray(p.getString(k, "[]"))
        return (0 until a.length()).map { a.getJSONObject(it).let { o -> Item(o.getString("s"), o.getString("t"), o.getString("i"), o.getString("o")) } }
    }

    fun save(k: String, l: List<Item>) {
        val a = JSONArray()
        l.take(100).forEach { a.put(JSONObject().put("s", it.s).put("t", it.t).put("i", it.i).put("o", it.o)) }
        p.edit().putString(k, a.toString()).apply()
    }
}
