# Navid Translate — Android (Kotlin + Jetpack Compose)

## Open and run
1. Install Android Studio (Koala or newer) and open this folder. Let Gradle sync.
2. Run on a device or emulator (Android 7.0+).

## Connect the backend (admin control)
Edit `app/build.gradle.kts`:
`buildConfigField("String", "BASE_URL", "\"https://your-server.example.com\"")`
- With a real URL: login/register is required, enabled languages come from `/api/config`, usage events go to `/api/event`, and the menu items for users, admin panel and stats open `/admin/` in the browser.
- Left as `YOUR-SERVER`: the app runs fully local, with no accounts.
HTTPS is required (cleartext is disabled).

## What runs offline (on device)
- Translation and language detection: Google ML Kit. Download each language pack once (Offline tab), then it works with no internet.
- Text-to-speech: Android TTS. Voices must be installed on the phone.
- Voice input: Android speech recognizer, set to prefer offline. It needs the offline speech pack installed in the Google app settings, otherwise it may use the internet.

## Known limits
- ML Kit translates about 59 languages. Pashto and Uzbek are not included. Dari uses the Persian model.
- Image text reading: Latin-script languages use ML Kit. Persian, Arabic, Urdu and Pashto use Tesseract, which needs data files: download `fas`, `ara`, `urd`, `pus` and `eng` `.traineddata` from github.com/tesseract-ocr/tessdata_fast and put them in `app/src/main/assets/tessdata/`. Without them, image translation for those languages shows an error. Accuracy on photos varies; Persian handwriting is not supported.
- Not compiled or tested here (no Android SDK in my environment). Expect to fix small build errors on first sync.

## Release build (Play Store / APK)
1. Create your signing key once and keep it safe. If you lose it you cannot update the app:
   `keytool -genkeypair -v -keystore navid-release.jks -alias navid -keyalg RSA -keysize 2048 -validity 10000`
2. Create `keystore.properties` in the project root (it is git-ignored):
   ```
   storeFile=navid-release.jks
   storePassword=...
   keyAlias=navid
   keyPassword=...
   ```
3. Build: `./gradlew bundleRelease` (Play Store, `app/build/outputs/bundle/release/`) or `./gradlew assembleRelease` (APK).
4. Raise `versionCode` in `app/build.gradle.kts` for every upload.
5. Release builds shrink code (R8). If a release build crashes but debug works, set `isMinifyEnabled = false` and report the stack trace.
6. Before publishing: set the real HTTPS `BASE_URL`, add the tessdata files, and test on a real phone with airplane mode on.
