# Building a release

1. Create a signing key (once). Keep the .jks file and passwords safe and backed up: losing them means you can never update the app on Google Play.
   keytool -genkey -v -keystore navid-release.jks -alias navid -keyalg RSA -keysize 2048 -validity 10000
2. Copy `keystore.properties.example` to `keystore.properties` and fill in the values. This file is git-ignored.
3. Build:
   ./gradlew bundleRelease     -> app/build/outputs/bundle/release/app-release.aab (for Google Play)
   ./gradlew assembleRelease   -> app/build/outputs/apk/release/app-release.apk (for direct install)
4. Before each update, raise `versionCode` in app/build.gradle.kts.

## Before publishing
- Set BASE_URL to your HTTPS server and test login, language config and the admin panel end to end.
- Test the release build on a real phone: code shrinking (R8) can break things that work in debug, especially ML Kit and Tesseract.
- Google Play needs a privacy policy URL if accounts are used (the app sends email and language-pair usage to your server), plus the Data safety form.
- Minimum Android version is now 8.0 (API 26) because of the adaptive icon.
